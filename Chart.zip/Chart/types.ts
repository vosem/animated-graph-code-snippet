export type DataItem = {
  x: {
    value: number;
    text: string;
  };
  y: {
    value: number;
    text: string;
  };
};
