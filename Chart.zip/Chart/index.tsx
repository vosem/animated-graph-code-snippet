import React, { memo, useEffect, useRef, useState } from 'react';
import cx from 'classnames';
import { motion, useMotionValue } from 'framer-motion';

import { DataItem } from './types';
import useIntl from '#/hooks/useIntl';

import Chart from './utilities/Chart';
import { ReactComponent as RaysIcon } from './icons/rays.svg';

import styles from './styles.less';

type PointerStyle = {
  left: string;
  top: string;
  transition: string;
};

type Props = {
  data: Array<DataItem>;
  interval: number;
  itemsCount: number;
  rightPadding: number;
  adjustment: number;
};

const ChartWidget = memo(({
  data,
  interval,
  itemsCount,
  rightPadding,
  adjustment,
}: Props): JSX.Element => {
  const initialPointerSpot = {
    top: '50%',
    left: '94%',
    transition: 'none',
  };
  const x = useMotionValue(0);
  const { formatCurrency } = useIntl();
  const [graphTransition, setGraphTransition] = useState<string>('none');
  const [chart, setChart] = useState<Chart>(null);
  const [width, setWidth] = useState(0);
  const [showAnimation, setShowAnimation] = useState(false);
  const [pointerStyle, setPointerStyle] = useState<PointerStyle>(initialPointerSpot);
  const containerRef = useRef<HTMLDivElement>(null);
  const graphRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<HTMLCanvasElement>(null);
  const pointerRef = useRef<HTMLDivElement>(null);
  const fragmentWidth = width / (itemsCount);

  useEffect(() => {
    if (containerRef.current !== null) {
      setWidth(containerRef.current.clientWidth + fragmentWidth * 2 - rightPadding);
    }

    const resizeHandler = (): void => {
      setWidth(containerRef.current?.clientWidth + fragmentWidth * 2 - rightPadding);
      setShowAnimation(false);
    };

    resizeHandler();
    window.addEventListener('resize', resizeHandler);

    return (): void => {
      window.removeEventListener('resize', resizeHandler);
    };
  }, [containerRef.current]);

  useEffect(() => {
    if (width > 0) {
      const config = {
        data,
        frame: frameRef.current,
        graph: graphRef.current,
        fragmentWidth,
        formatCurrency,
      };

      setChart(new Chart(config));
    }
  }, [width]);

  const calculatePointerPosition = (): void => {
    const pointerOffset = pointerRef.current?.clientWidth / 2;
    const left = width - fragmentWidth * 2 - pointerOffset + 20;
    const top = chart.getYPixel(data[data.length - 1].y.value) as number + adjustment;
    // Avoid animation on mount
    const topTransition = `top ${showAnimation ? interval - 500 : 0}ms`;
    const leftTransition = `left ${showAnimation ? interval - 500 : 0}ms`;
    const transition = `${topTransition}, ${leftTransition}`;

    setPointerStyle({
      left: `${left}px`,
      top: `${top}px`,
      transition,
    });

    if (!showAnimation) {
      setShowAnimation(true);
    }
  };

  useEffect(() => {
    if (chart !== null) {
      chart.nextFragment(data);
      setGraphTransition(`${interval - 500}ms`);
      x.set(-width / itemsCount);
      calculatePointerPosition();
    }
  }, [data, chart]);

  const handleChange = (): void => {
    // Prepare mockup for next data
    const copy = [...data];

    copy.push(copy[copy.length - 1]);
    copy.shift();
    chart.nextFragment(copy);
    x.set(adjustment);
    setGraphTransition('none');
  };

  return (
    <div className={cx(styles.Chart)} ref={containerRef} >
      <motion.canvas
        className={styles.Graph}
        ref={graphRef}
        width={width}
        height={200}
        onTransitionEnd={handleChange}
        style={{ x, transition: graphTransition }}
      />
      <canvas
        ref={frameRef}
        width={width}
        height={200}
      />
      <div
        ref={pointerRef}
        className={styles.PointContainer}
        style={pointerStyle}
      >
        <div className={styles.Circle} />
        <RaysIcon className={styles.Rays} />
        <div className={styles.InfoText}>
          {formatCurrency(data[data.length - 1].y.value)}
        </div>
      </div>
    </div>
  );
});

ChartWidget.displayName = 'ChartWidget';

export default ChartWidget;
