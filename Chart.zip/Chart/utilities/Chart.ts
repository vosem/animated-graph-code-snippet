import { DataItem } from '../types';

const backgroundColor = '#252e41';
const graphFillColor = '#374562';
const frameColor = '#ffffff';

export default class Chart {
  private data: Array<DataItem>;

  private frame: HTMLCanvasElement;

  private graph: HTMLCanvasElement;

  private frameContext: CanvasRenderingContext2D;

  private graphContext: CanvasRenderingContext2D;

  private xPadding: number;

  private yPadding: number;

  private yMax: number;

  private scalingMultiplier: number;

  private width: number;

  private height: number;

  private fragmentWidth: number;

  private formatCurrency: (value: number, precision: number) => string;

  public constructor({
    data,
    frame,
    graph,
    fragmentWidth,
    formatCurrency,
  }) {
    this.data = data;
    this.frame = frame;
    this.graph = graph;
    this.frameContext = frame.getContext('2d');
    this.graphContext = graph.getContext('2d');

    this.width = this.graph.clientWidth;
    this.height = this.graph.clientHeight;
    this.fragmentWidth = fragmentWidth;

    this.xPadding = 30;
    this.yPadding = 30;
    this.yMax = 0;
    this.scalingMultiplier = 1;

    this.frameContext.lineWidth = 1.5;
    this.graphContext.lineWidth = 0.2;

    this.formatCurrency = formatCurrency;
  }

  public nextFragment(data): void {
    this.data = data;
    this.yMax = this.getMaxY();

    this.clearCanvas();
    this.drawQuads();
    this.drawLine();
    this.drawFrame();
  }

  public getMaxY(): number {
    let max = 0;

    for (let i = 0; i < this.data.length; i++) {
      if (this.data[i].y.value > max) {
        max = this.data[i].y.value;
      }
    }

    // Calculate visible y-scale step
    if (max <= 30) {
      this.scalingMultiplier = 3;
    } else if (max <= 200) {
      this.scalingMultiplier = 30;
    } else if (max <= 400) {
      this.scalingMultiplier = 40;
    } else if (max <= 3000) {
      this.scalingMultiplier = 300;
    } else if (max <= 10000) {
      this.scalingMultiplier = 3000;
    } else if (max <= 40000) {
      this.scalingMultiplier = 4000;
    } else if (max <= 100000) {
      this.scalingMultiplier = 30000;
    } else if (max <= 200000) {
      this.scalingMultiplier = 40000;
    } else {
      this.scalingMultiplier = 100000;
    }

    return max + this.scalingMultiplier * 2 - max % this.scalingMultiplier;
  }

  public getXPixel(value): number {
    return ((this.width - this.xPadding) / this.data.length) * value + (this.xPadding * 1.5);
  }

  public getYPixel(value): number {
    return this.height - (((this.height - this.yPadding - 10) / this.yMax) * value) - this.yPadding;
  }

  public clearCanvas(): void {
    this.frameContext.clearRect(
      0,
      0,
      this.width,
      this.height,
    );
    this.graphContext.clearRect(
      0,
      0,
      this.width,
      this.height,
    );
  }

  public drawFrame(): void {
    this.graphContext.font = '8pt sans-serif';
    this.graphContext.textAlign = 'center';

    // Draw left underlying background for y-axe
    this.frameContext.fillStyle = backgroundColor;
    this.frameContext.beginPath();
    this.frameContext.moveTo(0, 0);
    this.frameContext.lineTo(0, this.height - 20);
    this.frameContext.lineTo(this.xPadding * 2 + 5, this.height - 20);
    this.frameContext.lineTo(this.xPadding * 2 + 5, 0);
    this.frameContext.fill();

    // Draw x and y axes
    this.frameContext.lineWidth = 1.5;
    this.frameContext.strokeStyle = frameColor;
    this.frameContext.beginPath();
    this.frameContext.moveTo(this.xPadding * 2 + 5, this.yPadding - 5);
    this.frameContext.lineTo(this.xPadding * 2 + 5, this.height - this.yPadding);
    this.frameContext.lineTo(this.width, this.height - this.yPadding);
    this.frameContext.stroke();

    // Draw right underlying background for x-axes
    this.frameContext.fillStyle = backgroundColor;
    this.frameContext.beginPath();
    this.frameContext.moveTo(this.width - this.fragmentWidth * 2 + 18, 0);
    this.frameContext.lineTo(this.width, 0);
    this.frameContext.lineTo(this.width, this.height - 20);
    this.frameContext.lineTo(this.width - this.fragmentWidth * 2 + 18, this.height - 20);
    this.frameContext.fill();

    // Render y-axe labels
    this.frameContext.lineWidth = 0.05;
    this.frameContext.fillStyle = frameColor;
    this.frameContext.textAlign = 'right';
    this.frameContext.textBaseline = 'middle';

    for (let i = 0; i < this.yMax; i += this.scalingMultiplier) {
      const label = this.formatCurrency(i, 0);

      this.frameContext.fillText(label, this.xPadding * 2, this.getYPixel(i));

      for (let n = 0; n < 2; n++) {
        // Drawing multiple times allows to strengthen the color without adding the width
        this.frameContext.beginPath();
        this.frameContext.moveTo(this.xPadding * 2 + 5, this.getYPixel(i));
        this.frameContext.lineTo(this.width - this.fragmentWidth * 2 + 18, this.getYPixel(i));
        this.frameContext.stroke();
      }
    }

    // Draw upper cover
    this.frameContext.fillStyle = backgroundColor;
    this.frameContext.beginPath();
    this.frameContext.moveTo(0, 0);
    this.frameContext.lineTo(this.width, 0);
    this.frameContext.lineTo(this.width, 20);
    this.frameContext.lineTo(0, 20);
    this.frameContext.fill();

    // Render x-axe labels not on frame
    // But on graph context in order to make them animated
    this.graphContext.fillStyle = frameColor;
    this.graphContext.strokeStyle = frameColor;

    for (let i = 0; i < this.data.length; i++) {
      this.graphContext.lineWidth = 1.5;
      this.graphContext.beginPath();
      this.graphContext.moveTo(this.getXPixel(i), this.height - this.yPadding);
      this.graphContext.lineTo(this.getXPixel(i), this.height - this.yPadding + 7);
      this.graphContext.stroke();

      this.graphContext.fillText(
        this.data[i].x.text,
        this.getXPixel(i),
        this.height - this.yPadding + 20,
      );
    }
  }

  public drawQuads(): void {
    this.graphContext.fillStyle = graphFillColor;

    for (let i = 0; i < this.data.length - 1; i++) {
      this.graphContext.beginPath();
      this.graphContext.moveTo(this.getXPixel(i), this.getYPixel(this.data[i].y.value));
      this.graphContext.lineTo(this.getXPixel(i + 1) + 1, this.getYPixel(this.data[i + 1].y.value));
      this.graphContext.lineTo(this.getXPixel(i + 1) + 1, this.height - this.yPadding);
      this.graphContext.lineTo(this.getXPixel(i), this.height - this.yPadding);
      this.graphContext.fill();
    }
  }

  public drawLine(): void {
    this.graphContext.lineWidth = 0.2;
    this.graphContext.strokeStyle = frameColor;
    this.graphContext.beginPath();
    this.graphContext.moveTo(this.getXPixel(0) + 1, this.getYPixel(this.data[0].y.value));

    for (let i = 1; i < this.data.length; i++) {
      this.graphContext.lineTo(this.getXPixel(i) + 1, this.getYPixel(this.data[i].y.value));
    }

    this.graphContext.stroke();
  }
}
